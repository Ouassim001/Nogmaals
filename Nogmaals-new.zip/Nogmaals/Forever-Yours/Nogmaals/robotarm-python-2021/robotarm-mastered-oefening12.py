from RobotArm import RobotArm

robotArm = RobotArm('exercise 12')

# Jouw python instructies zet je vanaf hier:
robotArm.speed = 2
for rij in range(10):
    robotArm.grab()
    color = robotArm.scan()
    if color != "red":
            robotArm.drop()
            robotArm.moveRight()
    else:
        for blok in range(1,10):
            robotArm.moveRight()
        robotArm.drop()
        for blok in range(10):
            robotArm.moveLeft()



# Na jouw code wachten tot het sluiten van de window:
robotArm.wait()
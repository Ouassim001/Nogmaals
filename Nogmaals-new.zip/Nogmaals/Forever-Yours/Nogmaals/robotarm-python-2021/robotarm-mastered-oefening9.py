from RobotArm import RobotArm

robotArm = RobotArm('exercise 9')

# Jouw python instructies zet je vanaf hier:
robotArm.speed = 2
for rij in range(1,5):
    for b in range(1,5):
        robotArm.grab()
        for g in range(1,7):
            robotArm.moveRight()
        robotArm.drop()
        for r in range(1,6):
            robotArm.moveLeft()
    for l in range(1,5):
        robotArm.moveLeft()


        

        

        




# Na jouw code wachten tot het sluiten van de window:
robotArm.wait()
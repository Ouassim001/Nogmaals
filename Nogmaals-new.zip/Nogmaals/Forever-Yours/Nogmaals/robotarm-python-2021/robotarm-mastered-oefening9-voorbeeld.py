from RobotArm import RobotArm

robotArm = RobotArm('exercise 10')

# Jouw python instructies zet je vanaf hier:
robotArm.grab()
for rij in range(10):
    for blok in range(10):
        robotArm.moveRight()
        robotArm.drop()
        


# Na jouw code wachten tot het sluiten van de window:
robotArm.wait()
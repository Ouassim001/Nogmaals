i = 1
while i < 13:
    print(i, "am")
    i = i + 1

i = 1
while i < 13:
    print(i, "pm")
    i = i + 1
som = 0
teller = 50
while som < 1000:
    print(teller)
    teller = teller + 1
    teller = teller + som
    
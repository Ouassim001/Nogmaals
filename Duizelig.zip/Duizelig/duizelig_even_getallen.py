n = int(input("enter a number="))
i=20
while(i<=n):
    print(i)
    i=i+2
input("done")
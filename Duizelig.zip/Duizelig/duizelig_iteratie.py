while True:
    x = input("hoe heet je?")
    if x =="ouassim":
        break